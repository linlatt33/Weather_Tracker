from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
import requests
import datetime


# Create your views here.

@login_required(login_url='login')
def index(request):
    if 'city' in request.POST:
        city = request.POST['city']
    else:
        city = 'myanmar'

    appid = '7b3f2ff111ac095c361dd44cee24d480'
    URL = 'https://api.openweathermap.org/data/2.5/weather'
    PARAMS = {'q': city, 'appid': appid, 'units': 'metric'}
    r = requests.get(url=URL, params=PARAMS)
    res = r.json()
    description = res['weather'][0]['description']
    icon = res['weather'][0]['icon']
    temp = res['main']['temp']
    day = datetime.date.today()
    context = {'description': description, 'icon': icon, 'temp': temp, 'day': day, 'city': city}
    return render(request, 'weatherapp/index.html', context)


def loginpage(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        try:
            user = User.objects.get(username=username)
        except:
            messages.error(request, 'User Does Not exist')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('index')
        else:
            messages.error(request, 'Please Recheck Your Username or Password')

    context = {}
    return render(request, 'weatherapp/login.html', context)


def logoutpage(request):
    logout(request)
    return redirect('index')
