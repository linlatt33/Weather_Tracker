from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="index"),
    path('login-page', views.loginpage, name="login"),
    path('logout-page', views.logoutpage, name="logout")
]